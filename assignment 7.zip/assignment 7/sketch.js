/*	
	Using an open API, parse the json or XML data to pull out various
 	bits of information.
	Then visualize this information on the screen in some way.
	OpenWeatherMap is another API that does not require API keys:
	http://openweathermap.org/API
	A few others are listed at the bottom of this link:
	https://github.com/processing/p5.js/wiki/Loading-external-files:-AJAX,-XML,-JSON
	See Chapter 18 in LP AND reference Chapter 12 in Make: Getting Started with P5.js
	This is due on November 10th and is worth 2 Exercises
*/

//https://data.cityofnewyork.us/resource/xx67-kt59.json?$limit=1000
var rats;
var ratsUrl = 'https://data.cityofnewyork.us/resource/xx67-kt59.json?$limit=1000'; //location of data 

var angles = []; //array for the drawing of the pie chart angles
var data = [];  //array to store the data
var legend = ["A", "B", "C", "others"];  //these 2 are used to keep the colors of the chart and the colors of the legend in unision 
var colors = ["blue", "green", "orange", "gray"];

function preload(){
	getRats();   // preloads the JSON
}

function setup(){
	var a = 0;   //declares the four different data types to be used
	var b = 0;
	var c = 0;
	var other = 0;
	for(var i = 0; i < rats.length; i++) {  // if the grade of the restaurant is A add one to a
		if(rats[i].grade == 'A') {
			a++;
		}
		else if(rats[i].grade == 'B') { // if not A but is B add one to B
			b++;
		}
		else if(rats[i].grade == 'C') { // and so on
			c++;
		}
		else other++;
	}	
	console.log("A: " + a); //logs A:"insert number here"
	console.log("B: " + b);
	console.log("C: " + c);
	console.log("Other: " + other);	

	data.push(a); // pushes the data into an array
	data.push(b);
	data.push(c);
	data.push(other);

	angles.push(a/1000 * 360); //these fill the angles array with the correct amount to fill the pie chart for each result
	angles.push(b/1000 * 360);
	angles.push(c/1000 * 360);
	angles.push(other/1000 * 360);

	createCanvas(720, 400); //makes the page size
	noLoop(); //doesnt loop 
}

function draw() {
  background(240); //background color
  pieChart(300); // calls the pie chart function 
}

function pieChart(diameter) { // tells us what i pie chart is
  var lastAngle = 0;
  textSize(40);
  for (var i = 0; i < angles.length; i++) { // used an array for both colors and legend in the same for loop so that they would match the same colors 
    fill(colors[i]);
    text((legend[i] + ": " + str(data[i])), 20, height/2 + 40*i); //text is a combination of the legend letter followed by  : and finally the data collected in array data
    arc(width/2, height/2, diameter, diameter, lastAngle, lastAngle+radians(angles[i])); //draws the chart 
    lastAngle += radians(angles[i]); //each amount has a different degree
  }
}

// this is gonna grab the NYC open data stuff
function getRats(){
	 // this will download the city open data on the health violations:
  rats = loadJSON(ratsUrl, ratsDownloaded); // asynchronous API call
}

function ratsDownloaded(rats){
	// this will run once the city open data is grabbed
	console.log(rats.length); 
}
